function [dt] = CalDt(h,u,dx,index,timesave,tt)

    CFL = 0.85;
    tol=1e-5;
    g=9.81;

    %% calculate time step
    aI=abs(u)+abs(sqrt(g.*h));
    dt=CFL*dx/max(aI+tol);
    if tt+dt > timesave*(index-1)
        dt = timesave*(index-1)-tt;
    end
           
end



