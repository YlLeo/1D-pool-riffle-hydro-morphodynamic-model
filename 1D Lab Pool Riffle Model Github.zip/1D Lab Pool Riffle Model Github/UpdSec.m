function [zb,delta,fI] = UpdSec(dx,dt,Qb,sfeed,zb,Pbi,Fs,Pup,Po,B,La,Laold,Sny,x,fai)
    Gl=length(Pbi(:,1));
    Nn=length(Qb);

    dQdx=zeros(1,Nn);
    Qb(1)=sfeed;
    dQdx(2:Nn)=(Qb(2:Nn)-Qb(1:Nn-1))./dx;
    dQdx=dQdx.*(x>0.45).*(x<16.05); % 0.5~16
    dQdx=dQdx.*Sny;
    
    dzb=-1./(1-Po)./B.*dQdx.*dt;
    zb=zb+dzb;
    
    %% delta
    delta=dzb-(La-Laold);
    
    %% calculate internal grain distribution between fs and Fs
    tol=1e-10;
    temp=fai.*Pbi+(1-fai).*Fs;
    dir=ones(Gl,1)*dzb;
    fI=Pup.*(dir<=0)+temp.*(dir>0);          

end
