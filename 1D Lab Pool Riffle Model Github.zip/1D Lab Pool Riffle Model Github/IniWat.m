function [h,u] = IniWat(B,ks,S0) 

    swf=2; %1-calculate initial; 2-read initial; 3-read from results
   
    % give h, z, and q
    if swf==1
        [h,u] = Uniformflow(ks,B,S0);
    else if swf==2     
        GG=load('Iniwater.txt');
        h=GG(:,1)';
        u=GG(:,2)';
    else
        load('waterdepth1.mat');
        load('unitdischarge1.mat');
        h=hsave(end,:);   
        u=usave(end,:);  
    end
    
end



