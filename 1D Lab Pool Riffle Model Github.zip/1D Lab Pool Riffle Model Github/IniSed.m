function [ds,dsf,dsg,Fs,fs,Gl,sfeed,sfeedi] = IniSed(zb)

   Nn=length(zb);
   sdf=1; %1-culmulative grain file; 2-single fraction file
   rhos=2650;
   sfs=1; %1-give initial grain size distributions; 2-read initial grain size distributions

   Sedinput=load('IniSed.txt');
   if sdf == 1
       dsg=Sedinput(:,1)'/1000; % dsg-all grain
       psg=Sedinput(:,2)';
       fsg=Sedinput(:,3)';   
       Gl=length(dsg)-1;
       dsf=0.5*(psg(1:Gl)+psg(2:Gl+1)); % dsf-representive grain in log
       ds=2.^dsf./1000; % ds-representive grain
       ft=fsg(2:Gl+1)-fsg(1:Gl);
   else   
       ds=Sedinput(:,1)'./1000;
       ft=Sedinput(:,2)'./100;
       Gl=length(ds);
       dsf=log2(ds.*1000);
   end
   
   if sfs==1
       for i=1:Nn
           Fs(:,i)=ft; % Grain distributions in the active layer
       end
   else
       load('bed surface4.mat');
       for i=1:Nn
           Fs(:,i)=Fssave(4,:,i); 
       end
   end
   
   fs=Fs;
   sfeed=0.5/60/rhos; % transport rate Qt, m^3/s, boundary for node x = 0.5 m
   sfeedi=ft'; % Pbi
           
end