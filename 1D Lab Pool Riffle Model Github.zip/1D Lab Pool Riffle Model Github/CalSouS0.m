function [S0] = CalSouS0(dx,zb) 
            
    tol = 1e-5;
    Nn=length(zb);
    
    % Slope terms
    S0(1:Nn-1)=-(zb(2:Nn)-zb(1:Nn-1))./dx; % Keep the bed slope positive
    S0(Nn)=S0(Nn-1);
    
end