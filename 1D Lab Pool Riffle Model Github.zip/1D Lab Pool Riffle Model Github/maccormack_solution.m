%MACCORMACK SCHEME - SOLUTION STEP
function [h,u] = maccormack_solution(Dp,Up,Dc,Uc)

    h = 0.5 * (Dp + Dc);
    u = 0.5 * (Up + Uc);

return