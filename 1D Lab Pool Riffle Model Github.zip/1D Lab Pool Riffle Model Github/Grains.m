function [dg,d50,La,Po,Fss,ks] = Grains(Fs,dsf,dsg,x,na)
% Based on Parker's ebook

   fg=dsf*Fs;
   dg=2.^fg./1000;  % Geometry median size
   Gl=length(dsg);
   Nn=length(Fs(1,:));
   sumFs(Gl,Nn)=0;
   tol=1e-5;

   sumFs(1,:)=0;
   for i=2:Gl
      sumFs(i,:)=sumFs(i-1,:)+Fs(i-1,:);
   end
   Fss=sumFs(5,:); % Sand percent in %

   ppd=0.90;
   for i=1:Nn
      cd1=find(sumFs(:,i)<ppd,1,'last');
      cd2=find(sumFs(:,i)>ppd,1,'first');
      if isempty(cd1)
          d90(i)=dsg(1);
      else
          temp=(dsg(cd2)-dsg(cd1))./(sumFs(cd2,i)-sumFs(cd1,i)+tol);
          d90(i)=dsg(cd1)+temp.*(ppd-sumFs(cd1,i));
      end
      La(i)=na.*d90(i);
   end
   
   nk=2; % actually this parameter can be adjusted
   ks=nk.*d90;
   
   ppd=0.50;
   for i=1:Nn
      cd1=find(sumFs(:,i)<ppd,1,'last');
      cd2=find(sumFs(:,i)>ppd,1,'first');
      if isempty(cd1)
          d50(i)=dsg(1);
      else
          temp=(dsg(cd2)-dsg(cd1))./(sumFs(cd2,i)-sumFs(cd1,i)+tol);
          d50(i)=dsg(cd1)+temp.*(ppd-sumFs(cd1,i));
      end
   end
   
   %% Bed porosity
   Po=ones(1,Nn)*0.145;
           
end