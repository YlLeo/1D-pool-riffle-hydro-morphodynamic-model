function [SM,Mf,Ls,Fai,Na,Sny] = RedPara( varargin )

   SM=1; % 1-Wilcock & Crowe 2003
   Mf=1;
   Ls=0.02; % set storage layer thickness
   Fai=0.7; % Interface grain distributions
   Na=2; % Active layer thickness
   Sny=1; % 1-consider sediment; 0-just flow
           
end



