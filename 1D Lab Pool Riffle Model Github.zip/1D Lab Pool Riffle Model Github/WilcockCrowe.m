function [Pbi,Qb] = WilcockCrowe(ds,dg,Fs,Fss,B,Mf,taob)
% Based on Parker's ebook
    g=9.81;
    s=1.65;
    tol=1e-5;
    Nn=length(B);
    Gl=length(ds);
    rhow=1000;
    taossrgC=1;
    taobC=1;

    % calculate bed shear velocity   
    ustar2=taob./rhow*taobC;
    ustar=sqrt(ustar2);
    
    taosg=ustar2./s./g./dg;
    taossrg=0.021+(0.015.*exp(-20.*Fss));
    taossrg=taossrg * taossrgC;
    phisgo=taosg./taossrg;
    
    Qbi=zeros(Gl,Nn);
    for i=1:Gl
        b=0.67./(1+exp(1.5-ds(i)./dg));
        arg=phisgo.*(ds(i)./dg).^(-b);
        GGwc1=0.002.*arg.^7.5;
        GGwc2=14.*(1-0.894./(arg.^0.5)).^4.5;
        Wstar=GGwc1.*(arg<1.35)+GGwc2.*(arg>=1.35);
        
        Wstar=Wstar.*(phisgo>=tol);
        Qbi(i,:)=Mf.*Wstar.*Fs(i,:).*ustar.^3./s./g.*B;
    end
    
    Qb=zeros(1,Nn);
    for i=1:Nn
        Qb(i)=sum(Qbi(:,i));
    end
    
    Pbi=zeros(Gl,Nn);
    for i=1:Gl
        Pbi(i,:)=Qbi(i,:)./(Qb(1,:)+1e-10);
    end
    
end

