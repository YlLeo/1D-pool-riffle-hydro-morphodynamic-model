% MACCORMACK SCHEME - CORRECTION STEP
function [Dc, Uc] = maccormack_correction(dt, dx, S0, ...
                                    Ut, Dt, Uf, Df, Se, Dus, Uus, Dds, Uds,B)

g=9.81;
n=length(S0);
                                
% allocate arrays
Dc = nan(1,n);
Uc = nan(1,n);

% set boundary conditions
Dc(1)   = Dus;
Uc(1)   = Uus;
Dc(end) = Dds;
Uc(end) = Uds;

% backward loop over nodes
for j = n-1:-1:2
    Dc(j) = Dt(j) - dt/dx * ( Uf(j+1)*Df(j+1) - Uf(j)*Df(j) )- ...
        dt/dx * Uf(j)*Df(j)/B(j)*(B(j+1)-B(j));
    Uc(j) = Ut(j) - dt/dx * ( (Uf(j+1)^2 - Uf(j)^2)/2 + ...
            g*(Df(j+1)-Df(j))) - g * dt * (Se(j)-S0(j));
end

% end of the function
return