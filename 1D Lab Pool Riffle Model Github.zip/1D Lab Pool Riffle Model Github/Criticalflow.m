% SUPER CRITICAL FLOW
function [h,u] = Criticalflow(B)

    Q=42e-3;
    qw=Q./B;
    g=9.81;
    
    h=82.23e-3;
    u=qw./h;

return
