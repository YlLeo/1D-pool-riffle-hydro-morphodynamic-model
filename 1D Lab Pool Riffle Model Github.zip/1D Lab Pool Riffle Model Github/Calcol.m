function [T,timesave,NoS] = Calcol( varargin )

   T=2150*60;
   timesave=5*60;
   NoS=T/timesave;
           
end



