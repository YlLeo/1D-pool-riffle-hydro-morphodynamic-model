function [Sf,taob] = CalSouSf(h,u,B,ks,x) 
            
    rhow=1e3;
    g=9.81;
    vis=1e-6;
    
    R=(B.*h)./(B+2.*h);
    
    % bed & wall roughness
    nb=ks.^(1/6)./8.1./sqrt(g);
    kes=2.5e-3;
    nw=kes.^(1/6)./8.1./sqrt(g); 
      
    % roughness from bed and wall roughness
    ntemp=(B.*nb.^1.5+2.*h.*nw.^1.5)./(B+2.*h);
    n=ntemp.^(2/3);
       
    % friction terms
    Sf=n.^2.*u.^2./R.^(4/3);
    Rb=(nb.*u./sqrt(Sf+1e-10)).^(1.5); % the same friction slope for bed and the whole channel
    taob=rhow.*g.*Rb.*Sf;
    
    %% bed roughness for light table, hydraulic smooth
    Rt=R(x>16);
    Rnt=4.*u(x>16).*Rt./vis;
    Nt=length(Rnt);
    Nb=length(x)-Nt;
    ft=1e-2;
    tol=100;
    for i=1:Nt
        while tol > 1e-1
            ft=ft+1e-4;
            tempL=sqrt(1./ft);
            tempR=2.*log10(Rnt(i).*sqrt(ft))-0.8;
            tol=abs(tempL-tempR);
        end
        temp=Rt(i).^(1/3).*ft./8./g;
        n(Nb+i)=sqrt(temp);
        Sf(Nb+i)=n(Nb+i).^2.*u(Nb+i).^2./Rt(i).^(4/3);
    end
    
end