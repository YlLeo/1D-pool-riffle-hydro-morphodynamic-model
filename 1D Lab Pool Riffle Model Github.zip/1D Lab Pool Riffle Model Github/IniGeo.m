function [dx,B,x,zb,Nn,zbo] = IniGeo( varargin )
% The nodes 1 & Nn are fake nodes.

   % spatial resolution
   L=15.6+2;
   dx=0.1;
   x=0.4:dx:18;
   Nn=length(x); 
   IniG=1; % 1-Give directly; 2-read from results
   
   % give zb and B
   if IniG == 1
       zb=0.17+(16-x)*0.015;
   else
       WS0=load('ws15.txt');
       n=length(WS0(:,1));
       zb1=0.17+(16+3)*0.015;
       zb2=0.17+(16-18)*0.015;
       xw(1)=-3;
       xw(2:n+1)=WS0(:,1);
       xw(n+2)=18;
       WS(1)=zb1;
       WS(2:n+1)=WS0(:,3);
       WS(n+2)=zb2;
       zb=interp1(xw,WS,x);
   end
   GG=load('Width change.txt'); % The range of x must inside the range of GG(:,1)
   B=interp1(GG(:,1),GG(:,2),x);
      
   % no need for change
   zbo=zb; 
   
end



