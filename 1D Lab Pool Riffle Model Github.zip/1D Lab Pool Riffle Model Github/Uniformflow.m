% UNIFORM FLOW
function [h,u] = Uniformflow(ks,B,S0)

    Q=42e-3;
    qw=Q./B;
    ar=8.1;
    g=9.81;
    
    h=(ks.^(1/3).*qw.^2./ar.^2./g./abs(S0)).^(0.3); % S0 should be positive when use this formula
    u=qw./h;

return
