function [Fs,Laold] = GrainUpd(Qb,Pbi,sfeed,sfeedi,Po,Fs,B,fI,La,Laold,dt,dx,Sny,x)
   
   tol=1e-16;
   Nn=length(Po);
   Gl=length(Pbi(:,1));

   dQdx=zeros(1,Nn);
   Qb(1)=sfeed;
   dQdx(2:Nn)=(Qb(2:Nn)-Qb(1:Nn-1))./dx;
   dQdx=dQdx.*(x>0.45).*(x<16.05); % 0.5~16
   dQdx=dQdx.*Sny;
   
   dQpdx=zeros(Gl,Nn);
   Pbi(:,1)=sfeedi;
   for i=1:Gl
       dQpdx(i,2:Nn)=(Qb(2:Nn).*Pbi(i,2:Nn)-Qb(1:Nn-1).*Pbi(i,1:Nn-1))./dx;
   end
   for i=1:Gl
       dQpdx(i,:)=dQpdx(i,:).*(x>0.45).*(x<16.05);
   end
   dQpdx=dQpdx.*Sny;
   
   for i=1:Gl
       temp=dt./(La.*(1-Po))./B;
       Fsnew=Fs(i,:)-dQpdx(i,:).*temp+fI(i,:).*dQdx.*temp;
       Fsnew=Fsnew-(Fs(i,:)-fI(i,:)).*(La-Laold)./La;
       Fs(i,:)=max(Fsnew,0);
   end

   Laold=La;
   
   for i=1:Nn
       SFs(i)=sum(Fs(:,i));
   end

   for i=1:Gl
       Fs(i,:)=Fs(i,:)./(SFs+tol);
   end   
      
end



