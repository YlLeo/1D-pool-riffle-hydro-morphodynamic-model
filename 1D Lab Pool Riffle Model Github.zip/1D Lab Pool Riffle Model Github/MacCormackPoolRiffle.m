%% 1d Pool Riffle morphodynamics model
    format long e
    clc
    clear
    close all
    
    [SM,Mf,Ls,Fai,Na,Sny] = RedPara;
    
    %% Topography, flow and sediment need to be given
    [dx,B,x,zb,Nn,zbo] = IniGeo;
    [S0] = CalSouS0(dx,zb);
    [ds,dsf,dsg,Fs,fs,Gl,Sfeed,Sfeedi] = IniSed(zb);
    [dg,d50,La,Po,Fss,ks] = Grains(Fs,dsf,dsg,x,Na);
    kus=ks(1);
    kds=ks(Nn);
    Sus=S0(1);
    Sds=S0(Nn);
    [h,u] = IniWat(B,ks,S0);
    [T,timesave,NoS] = Calcol;
    CaseNum=1;
    
    %% For Storage and start, h,u,zb,z
    hsave=zeros(NoS,Nn);
    usave=zeros(NoS,Nn);
    zbsave=zeros(NoS,Nn);
    zsave=zeros(NoS,Nn);
    bssave=zeros(NoS,Nn); % bed shear stress
    Qbsave=zeros(NoS,Nn); % sediment transport rate in total
    Pbsave=zeros(NoS,Gl,Nn); % sediment transport fractions
    dgsave=zeros(NoS,Nn);
    Fssave=zeros(NoS,Gl,Nn);
    Qssave=zeros(NoS,1); % outflow sediment discharge
    time=zeros(NoS,1); 
    
    index=1;
    hsave(index,:)=h;
    usave(index,:)=u;
    zbsave(index,:)=zb;
    zsave(index,:)=h+zb;    
    Fssave(index,:,:)=Fs;
    time(index,1)=0;
    Qssave(index,1)=0;
    Laold=La;
    
    Store=cell(1,Nn);
    indup=ceil((zb-La+10*Ls)./Ls);
    for is=1:Nn
        Store{1,is}=zeros(Gl,100);
        Store{1,is}(:,1:indup(is))=fs(:,1)*ones(1,indup(is));
    end
    Pup=fs; % uppermost storage layer grain distribution  
    Lup=zb+10*Ls-La-Ls*(indup-1); % uppermost storage layer thickness
    
    tt = 0;
    index=index + 1;
    step=1;
    outtran=0;
    
    %% Calculation
    while tt <= T  
        
        %% Step 0 Calculate time step CFL (dt)
        [dt] = CalDt(h,u,dx,index,timesave,tt);
        [dg,d50,La,Po,Fss,ks] = Grains(Fs,dsf,dsg,x,Na);
        
        %% Step 1 Calculate local friction and bed slope
        [Sf,taob] = CalSouSf(h,u,B,ks,x); 
        [S0] = CalSouS0(dx,zb);
        
        %% Step 2 Boundary conditions: upstream hus&uus and downstream hds&uds
        [hus,uus] = Criticalflow(B(1)); 
        [hds,uds] = Freeflow(h(Nn-1),u(Nn-1)); 
        
        %% Step 3 Prediction step
        [Hp,Up] = maccormack_prediction(dt, dx, S0, ...
                                    u, h, u, h, Sf, hus, uus, hds, uds,B);
        
        %% Step 4 ARTIFICIAL VISCOSITY
        [Hp,Up] = maccormack_viscosity(Hp,Up);
        
        %% Step 5 CORRECTION STEP and SOLUTION STEP
        [Sf,taob] = CalSouSf(Hp,Up,B,ks,x);
        [Hc,Uc] = maccormack_correction(dt, dx, S0, ...
                                    u, h, Up, Hp, Sf, hus, uus, hds, uds,B);
        [h,u] = maccormack_solution(Hp,Up,Hc,Uc);
        z=h+zb;
        
        %% Step 6 Calculate Qs   
        [Sf,taob] = CalSouSf(h,u,B,ks,x); 
        if SM == 1
            [Pbi,Qb] = WilcockCrowe(ds,dg,Fs,Fss,B,Mf,taob);
        end
        
        %% Step 7 update zb   
        [zb,delta,fI] = UpdSec(dx,dt,Qb,Sfeed,zb,Pbi,Fs,Pup,Po,B,La,Laold,Sny,x,Fai);
        
        %% Step 8 update active layer
        [Fs,Laold] = GrainUpd(Qb,Pbi,Sfeed,Sfeedi,Po,Fs,B,fI,La,Laold,dt,dx,Sny,x);
        
        %% Step 9 update storage layer 
        indn=find((delta<=Ls-Lup)&(delta>=-Lup)); % within the same layer
        indinc=find(delta>Ls-Lup); % aggrade to upper layer
        inddec=find(delta<-Lup); % degrade to lower layer
        Pup(:,indn)=(Pup(:,indn).*(ones(Gl,1)*Lup(indn))+...
            fI(:,indn).*(ones(Gl,1)*delta(indn)))./(ones(Gl,1)*(Lup(indn)+delta(indn)));
        Lup(indn)=Lup(indn)+delta(indn);
        if size(indinc,2)>0
            for is=1:size(indinc,2)
                ii=indinc(is);
                Pup(:,ii)=(Pup(:,ii).*Lup(ii)+fI(:,ii).*(Ls-Lup(ii)))./Ls;
                Store{1,ii}(:,indup(ii))=Pup(:,ii);
                inc=ceil((delta(ii)-(Ls-Lup(ii)))/Ls);
                Store{1,ii}(:,indup(ii)+1:indup(ii)+inc)=fI(:,ii)*ones(1,inc);
                indup(ii)=indup(ii)+inc;
                Pup(:,ii)=fI(:,ii);
                Lup(ii)=delta(ii)-(Ls-Lup(ii))-(inc-1)*Ls;
            end
        end
        if size(inddec,2)>0
            for is=1:size(inddec,2)
                id=inddec(is);
                dec=ceil((-Lup(id)-delta(id))/Ls);
                Store{1,id}(:,indup(id)-dec+1:indup(id))=zeros(Gl,dec);
                indup(id)=indup(id)-dec;
                Pup(:,id)=Store{1,id}(:,indup(id));
                Lup(id)=dec*Ls+Lup(id)+delta(id);
            end
        end
        
        %% Summerize output sediment flux
        outfluxs=Qb(x==16);
        outtran=outtran+outfluxs*dt*2650;
        
        if tt == 0
            Qbsave(1,:)=Qb;
            Pbsave(1,:,:)=Pbi;
            dgsave(1,:)=dg;
            bssave(1,:)=taob;
        end
        
        tt=tt+dt;       
        if tt-timesave*(index-1) >= 0
            hsave(index,:)=h;
            usave(index,:)=u;
            zbsave(index,:)=zb;
            zsave(index,:)=z;
            bssave(index,:)=taob;
            Qbsave(index,:)=Qb;
            Pbsave(index,:,:)=Pbi;
            dgsave(index,:)=dg;
            Fssave(index,:,:)=Fs;
            Qssave(index,1)=outtran;
            outtran=0;
            time(index,1)=tt;
            index = index + 1;
        end
        step=step+1;

    end
    
    %% For output
         plot(x,z,'b-')
         hold on
         plot(x,zbo,'k-')
         hold on
         plot(x,zb,'r-')
         xlim([0 16])

    Filname=['waterdepth' num2str(CaseNum) '.mat'];
    save(Filname,'hsave');
    Filname=['flowvelocity' num2str(CaseNum) '.mat'];
    save(Filname,'usave');
    Filname=['bedelevation' num2str(CaseNum) '.mat'];
    save(Filname,'zbsave');
    Filname=['watersurface' num2str(CaseNum) '.mat'];
    save(Filname,'zsave');  
    Filname=['Bedshear' num2str(CaseNum) '.mat'];
    save(Filname,'bssave');
    Filname=['sedimentdischarge' num2str(CaseNum) '.mat'];
    save(Filname,'Qbsave');  
    Filname=['median size' num2str(CaseNum) '.mat'];
    save(Filname,'dgsave');
    Filname=['bed surface' num2str(CaseNum) '.mat'];
    save(Filname,'Fssave');
    Filname=['Outtran' num2str(CaseNum) '.mat'];
    save(Filname,'Qssave');
    Filname=['time' num2str(CaseNum) '.mat'];
    save(Filname,'time');
    Filname=['Storagelayer' num2str(CaseNum) '.mat'];
    save(Filname,'Store');
    Filname=['BedloadFractions' num2str(CaseNum) '.mat'];
    save(Filname,'Pbsave');