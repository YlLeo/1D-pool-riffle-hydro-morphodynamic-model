% FREE OUTFLOW
function [h,u] = Freeflow(hn,un)
    
    h=hn;
    u=un;

return
